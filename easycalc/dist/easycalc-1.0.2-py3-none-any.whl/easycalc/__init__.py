"""
Initclass but empty.
"""
