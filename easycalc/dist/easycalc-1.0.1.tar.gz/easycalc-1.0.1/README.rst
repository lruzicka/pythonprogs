EasyCalc
========

This is a very simple program that evaluates the expression using the **eval** function. I have written it as a concept to learn how to make a pip package.

Usage
-----

To use this script interactively, run it without any arguments:

command::
    easycalc

To use the script just to evaluate one expression, provide the expression as an argument. For expressions with bracket, use exclamation marks:

command::
    easycalc 5+5
    easycalc "(4+5+7)/3"


